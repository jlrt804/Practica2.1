﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _IPC2_J17_Practica2_201345126
{
    public partial class regEstudiante : System.Web.UI.Page
    {
        wsP2.API ws = new wsP2.API();
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ws.crearEstudiante(201345126, int.Parse(txtCarnet.Text), txtNombre.Text, txtApellido.Text);
        }
    }
}