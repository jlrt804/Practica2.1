﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _IPC2_J17_Practica2_201345126
{
    public partial class crearEvento : System.Web.UI.Page
    {
        wsP2.API ws = new wsP2.API();
        protected void Page_Load(object sender, EventArgs e)
        {
            /*
            String[] lTipoEv = ws.getTiposDeEvento(201345126);
            int i = 0;
            for (i=0; i<lTipoEv.Length; i++) {
                listaTipoEvento.Items.Add(lTipoEv[i]);
            }*/


            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            txtNombreEv.Text = listaTipoEvento.SelectedItem.Text;
            //ws.crearEvento(201345126, txtNombreEv.Text, txtDescripcion.Text, listaTipoEvento.SelectedItem.Text);
        }
    }
}