﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _IPC2_J17_Practica2_201345126
{
    public partial class mostrarEstudiantes : System.Web.UI.Page
    {
        wsP2.API ws = new wsP2.API();
        int contador=0;
        protected void Page_Load(object sender, EventArgs e)
        {

            wsP2.estudiante[] estudiante = ws.getEstudiantes(201345126);
            

            for (int i=0; i<estudiante.Length;i++) {
                DropDownList1.Items.Add(estudiante[i].carnet.ToString());
                DropDownList1.DataValueField.Insert(i,estudiante[i].apellido);
            }
            

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            contador += contador;
            wsP2.evento[] evento = ws.MostrarEventos(201345126);
            





        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            wsP2.estudiante[] estudiante = ws.getEstudiantes(201345126);
            txtApellido.Text = DropDownList1.SelectedValue.ToString();
        }
    }
}